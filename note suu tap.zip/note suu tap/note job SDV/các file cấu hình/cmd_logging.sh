function logging
{
stat="$?"
cmd=$(history|tail -1)
if [ "$cmd" != "$cmd_old" ]; then
logger -p local1.notice "[2] STAT=$stat"
logger -p local1.notice "[1] PID=$$, PWD=$PWD, CMD=$cmd"
fi
cmd_old=$cmd
}
trap logging DEBUG
