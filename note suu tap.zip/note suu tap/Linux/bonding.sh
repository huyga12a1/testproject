#!/bin/bash

sed -i 's/"//g' /etc/sysconfig/network-scripts/ifcfg-eth*

echo -e "Insert Network Bonding Device1 : \c"
read device1

echo -e "Insert Network Bonding Device2 : \c"
read device2

echo -e "Select bond : \c"
read bond

echo -e "IP ADDRESS : \c"
read ip

echo -e "NETMASK : \c"
read netmask

echo -e "GATEWAY : \c"
read gateway


for i in $device1 $device2
	do
	sed -i 's/BOOTPROTO=dhcp/BOOTPROTO=none/'g /etc/sysconfig/network-scripts/ifcfg-$i
	sed -i 's/ONBOOT=no/ONBOOT=yes/g' /etc/sysconfig/network-scripts/ifcfg-$i
	sed -i 's/NM_CONTROLLED=yes/NM_CONTROLLED=no/g' /etc/sysconfig/network-scripts/ifcfg-$i
	echo "USERCTL=no" >> /etc/sysconfig/network-scripts/ifcfg-$i
	echo "MASTER=$bond" >> /etc/sysconfig/network-scripts/ifcfg-$i
	echo "SLAVE=yes" >> /etc/sysconfig/network-scripts/ifcfg-$i
	done

cat << EOF >> /etc/sysconfig/network-scripts/ifcfg-$bond
TYPE=Bond
BOOTPROTO=none
DEVICE=$bond
ONBOOT=yes
NM_CONTROLLED=no
USERCTL=no
IPADDR=$ip
NETMASK=$netmask
GATEWAY=$gateway
BONDING_OPTS="mode=1 miimon=100"
EOF

echo "alias	$bond	bonding" >> /etc/modprobe.d/bonding.conf
