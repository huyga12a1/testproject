#!/bin/bash

#Network Manager 플러그인 해제
sed -i 's/plugins/#plugins/g' /etc/NetworkManager/NetworkManager.conf

#Sysrq 매직키 활성화
sed -i 's/kernel.sysrq = 0/kernel.sysrq = 1/g' /etc/sysctl.conf
echo 'kernel.panic_on_io_nmi = 1' >> /etc/sysctl.conf
echo 'kernel.unknown_nmi_panic = 1' >> /etc/sysctl.conf
echo 'kernel.panic_on_unrecovered_nmi = 1' >> /etc/sysctl.conf

#Crond 메일링 해제
sed -i 's/MAILTO=root/MAILTO=""/g' /etc/crontab

#SELINUX 해제
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/sysconfig/selinux

#유저 프로세스 개수 제한값 해제
sed -i 's/\*/#\*/g' /etc/security/limits.d/90-nproc.conf
