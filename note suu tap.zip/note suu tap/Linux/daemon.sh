#!/bin/bash

#데몬 비활성화
demon_list="$(chkconfig --list | awk '{print $1 }' | cut -d ':' -f 1)"
for demon in $demon_list
        do
                chkconfig $demon off
        done

#데몬 활성화
demon_list="auditd blk-availability crond haldaemon irqbalance kdump lvm2-monitor mcelogd messagebus netfs network rsyslog sshd sysstat udev-post xinetd"
for demon in $demon_list
        do
                chkconfig $demon on
        done
