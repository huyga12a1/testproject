#!/bin/bash

mkdir /root/rockplace/backup
cp /etc/logrotate.conf /root/rockplace/backup
cp /etc/sysconfig/ntpd /root/rockplace/backup
cp /etc/init/control-alt-delete.conf /root/rockplace/backup

#swap
echo -e "1. swap size\n"
free -m | grep -i swap
echo -e "\n\n"

#boot file system
echo -e "2. boot file system\n"
cat /etc/fstab | grep -i "root_lv"
echo -e "\n\n"

#kernel boot crash kernel
echo -e "3. cmdlime crash kernel\n"
echo -e "/boot/grub/grub.conf\n"
cat /boot/grub/grub.conf | grep -i crashkernel 
echo -e "/proc/cmdline\n"
cat /proc/cmdline | grep -i crashkernel 
echo -e "uname -a\n"
uname -a
echo -e "\n\n"

#kdump install check
echo -e "4. kdump install check\n"
rpm -qa | egrep -i 'kdump|kexec'
echo -e "\n\n"

# kdump vmcore make filesystem size
echo -e "5. kdump vmcore make filesystem size\n"
echo -e "kdump.conf\n"
cat /etc/kdump.conf | grep -i path
echo -e "\n"
echo -e "df -h\n"
df -h | grep crash
echo -e "\n\n"

#kdump setting check
echo -e "6. kdump setting check\n"
echo -e "kdump.conf dumplevel\n"
cat /etc/kdump.conf | grep -i "message-level"
echo -e "\n\n"

#crash kernel
echo -e "7. cmdlime crash kernel\n"
echo -e "/boot/grub/grub.conf\n"
cat /boot/grub/grub.conf | grep -i crashkernel
echo -e "/proc/cmdline\n"
cat /proc/cmdline | grep -i crashkernel

#kdump service enable
echo -e "8. kdump service enable check\n"
echo -e "chkconfig\n"
chkconfig --list | grep kdump
echo -e "service status\n"
service kdump status
echo -e "\n\n"

#sysrq active
echo -e "9. sysrq active\n"
cat /etc/sysctl.conf | grep sysrq
echo -e "\n\n"

#nmi active
echo -e "10. nmi active\n"
cat /etc/sysctl.conf | grep nmi
echo -e "\n\n"

#Ctrl + Alt + Del
echo -e "11. Ctrl + Alt + Del not used\n"
echo -e "old\n"
cat /etc/init/control-alt-delete.conf | grep -i control
sed -i 's/start on control-alt-delete/\#start on control-alt-delete/g' /etc/init/control-alt-delete.conf
sed -i 's/exec \/sbin\/shutdown/\#exec \/sbin\/shutdown/g' /etc/init/control-alt-delete.conf
echo -e "new\n"
cat /etc/init/control-alt-delete.conf | grep -i control
echo -e "\n\n"

#eth duplex check
echo -e "12. eth duplex check\n"
for i in `ls /etc/sysconfig/network-scripts/ | grep "ifcfg-eth*" | cut -d '-' -f 2`
do
ethtool $i | egrep -i 'eth|duplex'
done;

#dns not used

# ntp enable check
echo -e "13. ntp pkg check\n"
rpm -qa | grep ntp
echo -e "ntp ps check\n"
ps -ef | grep ntp | grep -v grep
echo -e "ntp enable check\n"
chkconfig --list | grep ntp
echo "ntpq -p\n"
ntpq -p
echo -e "\n\n"

#ntp slew option check
echo -e "14. ntp slew option check\n"
echo -e "old\n"
cat /etc/sysconfig/ntpd | grep -i option
sed -i 's/run\/ntpd.pid -g/run\/ntpd.pid -g -x/g' /etc/sysconfig/ntpd
echo -e "new\n"
cat /etc/sysconfig/ntpd | grep -i option
service ntpd restart
echo -e "\n\n"

#network bonding setting
echo -e "15. network bonding setting\n"
echo -e "ifcfg file bonding option\n"
cat /etc/sysconfig/network-scripts/ifcfg-bond0 | grep -i opts
echo -e "ifconfig\n"
ifconfig bond0
echo -e "\n"
echo -e "proc file\n"
cat /proc/net/bonding/bond0
echo -e "\n\n"

# multipath not used

# rootvg / datavg 
echo -e "16. rootvg / datavg"
vgs

#logrotate setting
echo -e " 17. logrotate setting"

cat << EOF > /etc/logrotate.conf
# see "man logrotate" for details
# rotate log files weekly
monthly

# keep 4 weeks worth of backlogs
rotate 12

# create new (empty) log files after rotating old ones
create

# use date as a suffix of the rotated file
dateext

# uncomment this if you want your log files compressed
#compress

# RPM packages drop log rotation information into this directory
include /etc/logrotate.d

# no packages own wtmp and btmp -- we'll rotate them here
/var/log/wtmp {
    monthly
    create 0600 root utmp
        minsize 1M
    rotate 12
}

/var/log/btmp {
    missingok
    monthly
    create 0600 root utmp
    rotate 1
}

# system-specific logs may be also be configured here.
EOF

cat /etc/logrotate.conf
